from flask import Flask, request, jsonify
import ollama

app = Flask(__name__)

@app.route('/ask', methods=['POST'])
def ask():
    data = request.json
    question = data['question']
    prompt = f"請用繁體中文回答以下問題：{question}"
    print(f"Received question: {question}")
    print(f"Using prompt: {prompt}")

    try:
        # 使用 ollama 的 Python SDK
        client = ollama.Client()
        response = client.generate(
            model="llamafamily/llama3-chinese-8b-instruct",
            prompt=prompt
        )
        answer = response.get('text', '').strip()

        # 手動截斷答案，限制為 150 個字
        max_tokens = 1000
        truncated_answer = ' '.join(answer.split()[:max_tokens])

        print(f"Generated answer: {truncated_answer}")
    except Exception as e:
        print(f"Error generating answer with ollama SDK: {e}")
        truncated_answer = "無法獲取回答"
    return jsonify({'answer': truncated_answer})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
